import { useRoute } from '@react-navigation/native';
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebaseConfig';
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, Alert, Linking, TouchableOpacity, Image } from 'react-native';
import BottomNavBar from './BottomNavBar';
import { SafeAreaView } from 'react-native-safe-area-context';

const Games = () => {
  const [displayedText, setDisplayedText] = useState('');
  const [displayedText2, setDisplayedText2] = useState('');
  const [userData, setUserData] = useState(null);
  const typingSpeed = 100; // Typing speed in milliseconds
  const route = useRoute();
  const mobileNumber = route.params?.mobileNumber;

  useEffect(() => {
    const fetchUserData = async () => {
      if (!mobileNumber) {
        Alert.alert('Error', 'Mobile number is not available');
        return;
      }

      try {
        const userDoc = doc(db, 'users', mobileNumber);
        const userSnapshot = await getDoc(userDoc);

        if (userSnapshot.exists()) {
          const data = userSnapshot.data();
          setUserData(data);
        } else {
          Alert.alert('Error', 'No user found with this mobile number');
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        Alert.alert('Error', 'Failed to fetch user data');
      }
    };

    fetchUserData();
  }, [mobileNumber]);

    useEffect(() => {
        setDisplayedText('')
        setDisplayedText2('')
    // Check if user data is available before starting typing effect
    if (!userData) return;

    const fullText = `Welcome, ${userData.name + "!" || 'No name'}`;
    const fullText2 = '  World of GAMES  '
   
    

    // Typing effect
    let index = 0;
    let index2 = 0;
    const typingInterval = setInterval(() => {
      if (index < fullText.length) {
          setDisplayedText((prev) => prev + fullText[index]);
          index++;
      } else {
          
        if (index2 < fullText2.length) {
            setDisplayedText2((prev) => prev + fullText2[index2]);
            index2++;
        } else {
        clearInterval(typingInterval);
      }
      }
        
    }, typingSpeed);

    // Cleanup function
    return () => {
      clearInterval(typingInterval);
    };
  }, [userData]);

    const goToMyBeat = () => {
        Linking.openURL(`https://kushagrasharma1004.github.io/myBeat/index.html?mobileNumber=${mobileNumber}`);
    }
    const goToMyBeat2 = () => {
        Linking.openURL(`https://kushagrasharma1004.github.io/myBeat2/index.html?mobileNumber=${mobileNumber}`);
    }

  return (
      <SafeAreaView style={{ flex: 1, }}>
          <View style={{ display:'flex', alignItems:'center'}}>
              <Text style={{ fontSize: 16 }}>{displayedText}</Text>
              <View style={{backgroundColor:'black', borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center', padding:0}} >
                  <Text style={{ fontSize: 18, fontWeight: 'bold', color:'white' }}>{displayedText2}</Text>
              </View>
          </View>

          <View style={{ padding: 20, display: 'flex', flexDirection: 'column' }} >
              <View style={{display:'flex', flexDirection:'row', gap:10}} >
            <TouchableOpacity onPress={goToMyBeat} style={{display:'flex', flexDirection:'column', borderWidth:1, width:73, height:70, alignItems:'center', justifyContent:'center', borderRadius:10}} >
            <Image style={{height:40, width:70}} source={require('../assets/images/gameController.jpg')} ></Image>
            <Text style={{fontSize:13}} >My Beat</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={goToMyBeat2} style={{display:'flex', flexDirection:'column', borderWidth:1, width:73, height:70, alignItems:'center', justifyContent:'center', borderRadius:10}} >
            <Image style={{height:40, width:70}} source={require('../assets/images/gameController.jpg')} ></Image>
            <Text style={{fontSize:13}} >My Beat 2</Text>
                  </TouchableOpacity>
              </View>
        </View>

          

          <BottomNavBar mobileNumber={mobileNumber} />
          

    </SafeAreaView>
  );
};

export default Games;

const styles = StyleSheet.create({});
