import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity } from 'react-native'
import React, { useState } from 'react'
import { Link, useRouter } from 'expo-router'
import { useRoute } from '@react-navigation/native';
import { useNavigation } from '@react-navigation/native';
const ForgotPassword = () => {
  const navigation = useNavigation();
    const screenWidth = Dimensions.get('window').width;
    const screenHeight = Dimensions.get('window').height;
    const router = useRouter();
  const route = useRoute();
  const mobileNumber = route.params?.mobileNumber;

  const goToSignUp = () => {
    router.push('./SignUp')
  };
    const createNewPassword = () => {
      
      router.push('./CreateNewPassword');
    }

    const goToHome = () => {
    navigation.navigate('Home', { mobileNumber });
  };
  
  return (
    <View>
          <View style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', height: screenHeight, width: screenWidth, gap: 10, alignItems: 'center' }} >
              
              <Text style={{ fontSize: 18, width:screenWidth-100}} >Enter OTP</Text>
              <TextInput placeholder='Enter OTP' style={{height:50, width:screenWidth-100, borderWidth:3, padding:10, borderRadius:7}}></TextInput>
             <TouchableOpacity onPress={goToHome} style={{ width: screenWidth - 100, borderWidth:3, borderRadius:7, height:50, alignItems:'center', justifyContent:'center', backgroundColor:'black', display:'flex' }}>
                  <Text style={{fontSize:16, color:'white'}} >Submit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={{width:screenWidth -100,}}>
                <Text style={{textAlign:'right', fontSize:14, color:'blue'}} >Resend OTP</Text>
                 </TouchableOpacity>
              </View>
      </View>
  )
}

export default ForgotPassword

const styles = StyleSheet.create({})