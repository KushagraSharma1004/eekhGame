import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity } from 'react-native'
import React, { useState } from 'react'
import { Link, useRouter } from 'expo-router'
import './main'
const ForgotPassword = () => {
    const screenWidth = Dimensions.get('window').width;
    const screenHeight = Dimensions.get('window').height;
    const router = useRouter();
    const [isOTPVisible, setIsOTPVisible] = useState(false);
    const [isSendOTPVisible, setIsSendOTPVisible] = useState(true);
    const [isSendOTPVisible2, setIsSendOTPVisible2] = useState(false);

  const goToSignUp = () => {
    router.push('./SignUp');
  };
    const createNewPassword = () => {
      
      router.push('./CreateNewPassword');
    }
  const showOTPInput = () => {
      setIsOTPVisible(!isOTPVisible);
      setIsSendOTPVisible(!isSendOTPVisible);
      setIsSendOTPVisible2(!isSendOTPVisible2);
  }
  return (
    <View>
          <View style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', height: screenHeight, width: screenWidth, gap: 10, alignItems: 'center' }} >
              
              <Text style={{ fontSize: 18, width:screenWidth-100}} >Reset Password</Text>
              <TextInput placeholder='Mobile Number' style={{height:50, width:screenWidth-100, borderWidth:3, padding:10, borderRadius:7}}></TextInput>
              {isOTPVisible && (
        <TextInput placeholder='Enter OTP' style={{height:50, width:screenWidth-100, borderWidth:3, padding:10, borderRadius:7}}></TextInput>
      )}
              { isSendOTPVisible &&(<TouchableOpacity onPress={showOTPInput} style={{ width: screenWidth - 100, borderWidth:3, borderRadius:7, height:50, alignItems:'center', justifyContent:'center', backgroundColor:'black', display:'flex' }}>
                  <Text style={{fontSize:16, color:'white'}} >Send OTP</Text>
              </TouchableOpacity>)}

              { isSendOTPVisible2 &&(<TouchableOpacity onPress={createNewPassword} style={{ width: screenWidth - 100, borderWidth:3, borderRadius:7, height:50, alignItems:'center', justifyContent:'center', backgroundColor:'black', display:'flex' }}>
                  <Text style={{fontSize:16, color:'white'}} >Submit</Text>
              </TouchableOpacity>)}

              <View style={{ display: 'flex', flexDirection: 'row', justifyContent:'space-evenly', alignItems:'flex-end', width:screenWidth-100 }} >
                  
              <TouchableOpacity style={{width:screenWidth -100,}}>
                <Text style={{textAlign:'right', fontSize:14, color:'blue'}} >Resend OTP</Text>
                 </TouchableOpacity>
                  
              </View>

              </View>
      </View>
  )
}

export default ForgotPassword

const styles = StyleSheet.create({})