import { StyleSheet, Text, View, Image, TouchableOpacity, Animated, Share, Alert, StatusBar } from 'react-native'
import React,{ useState, useEffect, useRef } from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import { router, useRouter } from 'expo-router'
import Menu from './Menu'
import BottomNavBar from './BottomNavBar'
import './main'
import { useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome5';
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebaseConfig';
const Home = () => {
  const bounceValue = useRef(new Animated.Value(1)).current;
  const [userData, setUserData] = useState(null);
  
  useEffect(() => {
    const bounce = () => {
      Animated.sequence([
        Animated.timing(bounceValue, {
          toValue: 1.1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(bounceValue, {
          toValue: 2,
          duration: 500,
          useNativeDriver: true,
        }),
      ]).start(() => bounce());
    };

    bounce();
  }, [bounceValue]);

  
  const route = useRoute();
  const router = useRouter()
  
  const mobileNumber = route.params?.mobileNumber;

  useEffect(() => {
  const fetchUserData = async () => {
    // if (!mobileNumber) {
    //   Alert.alert('Error', 'Mobile number is not available');
    //   setLoading(false);
    //   return;
    // }

    try {
      const userDoc = doc(db, 'users', mobileNumber);
      const userSnapshot = await getDoc(userDoc);

      // Debugging log to see what userSnapshot contains
      console.log('User Snapshot:', userSnapshot.data());

      if (userSnapshot.exists()) {
        const data = userSnapshot.data();
        
        // Debugging to check the type of data and specific fields
        console.log('User Data:', data);
        
        if (typeof data.name !== 'string') {
          console.error('Expected name to be a string, but got:', data.name);
        }

        setUserData(data);
      } else {
        Alert.alert('Error', 'No user found with this mobile number');
      }
    } catch (error) {
      // console.error('Error fetching user data:', error);
      // Alert.alert('Error', 'Failed to fetch user data');
    } finally {
      // setLoading(false);
    }
  };

  fetchUserData();
}, [mobileNumber]);
 console.log(mobileNumber)

  const openGames = () => {
    router.push(`./Games?mobileNumber=${mobileNumber}`)
  }

  const shareReferralCode = async () => {
    try {
      const result = await Share.share({
        message: `Referral Code: ${userData.selfReferralCode}`,
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with specific activity
          // Alert.alert('Shared via', result.activityType);
        } else {
          // shared
          // Alert.alert('Success', 'Content shared successfully');
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
        // Alert.alert('Cancelled', 'Content sharing dismissed');
      }
    } catch (error) {
      // Alert.alert('Error', 'An error occurred while sharing content');
    }
  };
  return (
      <View >
          <StatusBar 
        barStyle="light-content" // Change text color (options: 'light-content', 'dark-content')
        backgroundColor="black" // Change background color (any valid color)
      />
      <View style={{ height: ScreenHeight, width: ScreenWidth, padding: 10 }} >
        <View style={{height:ScreenHeight-200, padding:0}} >
        <TouchableOpacity onPress={openGames} style={{display:'flex', flexDirection:'column', borderWidth:1, width:73, height:70, alignItems:'center', justifyContent:'center', borderRadius:10 }} >
          <Image style={{height:40, width:70}} source={require('../assets/images/gameController.jpg')} ></Image>
          <Text style={{fontSize:13}} >Games</Text>
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity onPress={shareReferralCode} style={{backgroundColor:'#c9c9c4', height:60, width:ScreenWidth-20, borderRadius:10, display:'flex', flexDirection:'row', alignItems:'center', justifyContent:'space-evenly', marginTop:10}} >
         <Animated.View style={{ transform: [{ scale: bounceValue }]}}>
        <Icon name="gift" size={30} color="black" />
          </Animated.View>
          <View style={{display:'flex', flexDirection:'column'}} >
            <Text style={{color:'black'}} >Refer and earn</Text>
            <Text style={{color:'grey', fontSize:10}} >Earn unlimited* from every referral</Text>
          </View>

          <View style={{height:25, width:90, backgroundColor:'black', borderRadius:7, display:'flex', alignItems:'center', justifyContent:'center'}} ><Text style={{color:'white', fontSize:14}} >Refer Now</Text></View>
        </TouchableOpacity>
        
        
              
          </View>
          <BottomNavBar mobileNumber={ mobileNumber} />
          
    </View>
  )
}

export default Home

const styles = StyleSheet.create({})