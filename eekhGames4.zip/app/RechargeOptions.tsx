import { StyleSheet, Text, TouchableOpacity, View, Alert } from 'react-native';
import React, { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { db } from './firebaseConfig'; // Import your Firebase configuration
import { doc, updateDoc, collection, addDoc, query, where, getDocs, getDoc } from 'firebase/firestore';

const RechargeOptions = ({ mobileNumber }) => {
    const [selectedOption, setSelectedOption] = useState('365');
    const [rechargeOptionsVisible, setRechargeOptionsVisible] = useState(true);

    const options = [
        { id: '30', label: '30 Days', price: 120, duration: 30 },
        { id: '90', label: '90 Days', price: 340, duration: 90 },
        { id: '180', label: '180 Days', price: 650, duration: 180 },
        { id: '365', label: '365 Days', price: 1200, duration: 365 },
    ];

    const handleSelect = (id) => {
        setSelectedOption(id);
    };

    const distributeReferralBonus = async (referralCode, amount, index = 1) => {
    try {
        // Query to find the user who used this referralCode
        const q = query(collection(db, 'users'), where('selfReferralCode', '==', referralCode));
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
            const referringUser = querySnapshot.docs[0];
            const referringMobileNumber = referringUser.id; // Get the referring user's mobile number
            const referringUserRef = doc(db, 'users', referringMobileNumber);
            const referringUserDoc = await getDoc(referringUserRef);

            if (referringUserDoc.exists()) {
                let currentReferralAmount = referringUserDoc.data().referralAmount || 0;
                let newReferralAmount = currentReferralAmount + amount;

                // Update referralAmount for the current user
                await updateDoc(referringUserRef, { referralAmount: newReferralAmount });

                console.log(`Level ${index} - Updated referralAmount for ${referringMobileNumber}: ${newReferralAmount}`);

                // Retrieve next referralCode
                const nextReferralCode = referringUserDoc.data().referralCode;
                console.log(`Next Referral Code (Level ${index}): ${nextReferralCode}`);

                // Proceed to the next referral level only if the referral code exists and index <= 3
                if (nextReferralCode && index <= 50) {
                    let nextAmount;

                    // Define the bonus distribution for each level
                    if (index === 1) {
                        nextAmount = amount * 0.2; // Pass 70% to the next level
                    } else if (index <= 23 && index !== 1) {
                        nextAmount = amount * 0.9; // Pass 90% to the next level
                    } else if (index<= 50 && index !== 23){
                        nextAmount = amount * 1; // Pass 100% to the next level
                    }

                    console.log(`Passing ${nextAmount} to Level ${index + 1}`);
                    // Recursive call to distribute to the next level
                    await distributeReferralBonus(nextReferralCode, nextAmount, index + 1);
                } else {
                    console.log(`No more levels to process or max levels reached (Level ${index})`);
                }
            } else {
                console.error(`Referring user document does not exist for mobile number: ${referringMobileNumber}`);
            }
        } else {
            console.error(`No user found with referral code: ${referralCode}`);
        }
    } catch (error) {
        console.error('Error distributing referral bonus:', error);
    }
};


    

    const handleConfirm = async () => {
        setRechargeOptionsVisible(false);
        if (!selectedOption) {
            Alert.alert('Please select a recharge option.');
            return;
        }

        const selected = options.find(option => option.id === selectedOption);
        const { price, duration } = selected;

        // Calculate the expiry date
        const expiryDate = new Date(Date.now() + duration * 24 * 60 * 60 * 1000); // Current date + duration in milliseconds

        // Update the recharge balance in Firestore
        const userRef = doc(db, 'users', mobileNumber);

        try {
            const userDoc = await getDoc(userRef);
            let currentBalance = userDoc.exists() ? (userDoc.data().rechargeBalance || 0) : 0;

            // Update user's recharge balance and expiry date
            await updateDoc(userRef, {
                rechargeBalance: currentBalance + price, // Update balance
                rechargeExpiry: expiryDate // Set expiry date
            });

            const referralCode = userDoc.data().referralCode; // Assuming referralCode is stored in user data
            if (referralCode) {
                // Start with 20% of the recharge price
                const initialReferralAmount = price * 0.2;
                await distributeReferralBonus(referralCode, initialReferralAmount);
            }

            // Save recharge history
            await addDoc(collection(db, 'recharges'), {
                mobileNumber,
                amount: price,
                duration,
                expiryDate: expiryDate, // Set expiry date
                createdAt: new Date() // Store creation time
            });

            Alert.alert('Recharge Successful', `You have recharged for ${duration} days. Amount: ₹${price}`);
        } catch (error) {
            console.error('Error updating recharge balance:', error);
            Alert.alert('Error', 'Failed to recharge. Please try again.');
        }
    };

    return (
        <View style={{ borderWidth: 1, borderRadius: 7, maxHeight: 400, width: '50%', padding: 10, marginTop: 2, backgroundColor: 'white' }}>
            <Text style={{ fontSize: 12 }}>Recharge Options</Text>
            <View style={{ borderWidth: 1, borderColor: '#ccc', marginTop: 2 }} />
            <View style={{ marginTop: 10, gap: 10 }}>
                {options.map((option) => (
                    <View key={option.id} style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
                        <TouchableOpacity
                            style={{
                                width: 20,
                                height: 20,
                                borderWidth: 2,
                                borderColor: '#000',
                                justifyContent: 'center',
                                alignItems: 'center',
                                backgroundColor: selectedOption === option.id ? 'black' : 'transparent',
                            }}
                            onPress={() => handleSelect(option.id)}
                        >
                            {selectedOption === option.id && <Ionicons name="checkmark" size={15} color="white" />}
                        </TouchableOpacity>
                        <View style={{ display: 'flex', flexDirection: 'row', gap: 30, alignItems: 'center', justifyContent: 'center' }}>
                            <Text style={{ marginLeft: 5, fontSize: 13 }}>{option.label}</Text>
                            <Text style={{ fontSize: 13 }}>₹{option.price}</Text>
                        </View>
                    </View>
                ))}

                <TouchableOpacity
                    style={{ borderRadius: 7, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'black' }}
                    onPress={handleConfirm}
                >
                    <Text style={{ color: 'white' }}>Confirm</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default RechargeOptions;

const styles = StyleSheet.create({});
