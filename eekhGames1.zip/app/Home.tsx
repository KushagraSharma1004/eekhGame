import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native'
import React,{ useState, useEffect } from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import { useRouter } from 'expo-router'
import Menu from './Menu'
import BottomNavBar from './BottomNavBar'
import './main'
import { useRoute } from '@react-navigation/native';
const Home = () => {
  const route = useRoute();
  //  const [mobileNumber, setMobileNumber] = useState('');

  // useEffect(() => {
  //   // Get the mobileNumber passed from the previous screen
  //   const { mobileNumber } = route.params || {};
    
  //   if (mobileNumber) {
  //     setMobileNumber(mobileNumber);
  //   }
  // }, [route.params]);

  const mobileNumber = route.params?.mobileNumber;
  console.log(mobileNumber)

  return (
      <View >
          
          <View style={{ height: ScreenHeight, width: ScreenWidth }} >
              <Text>Home</Text>
        <BottomNavBar mobileNumber={ mobileNumber} />
              
          </View>
          
    </View>
  )
}

export default Home

const styles = StyleSheet.create({})