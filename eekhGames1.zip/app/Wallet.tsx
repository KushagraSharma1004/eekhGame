import { StyleSheet, Text, View, Image, TouchableOpacity, Button } from 'react-native'
import React, { useEffect, useState } from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import BottomNavBar from './BottomNavBar'
import { useRoute } from '@react-navigation/native'
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { app } from './firebaseConfig'; // Ensure your Firebase app is initialized here

const Wallet = () => {
  const [referralAmount, setReferralAmount] = useState(0);  // State to hold referralAmount
  const [Coins, setCoins] = useState(0);
  const route = useRoute();
  const mobileNumber = route.params?.mobileNumber;
  const [referralBackgroundColor, setReferralBackgroundColor] = useState('#ccc')
  const [coinsBackgroundColor, setCoinsBackgroundColor] = useState('white')
  const fetchReferralAmount = async (mobileNumber) => {
    try {
      const db = getFirestore(app);
      const docRef = doc(db, 'users', mobileNumber); // Assuming your Firestore structure has a collection 'users' with mobile numbers as document IDs
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const userData = docSnap.data();
        setReferralAmount(userData.referralAmount || 0); // Update referralAmount state with the fetched value
        setCoins(userData.Coins || 0)
      } else {
        console.log('No such document!');
      }
    } catch (error) {
      console.error('Error fetching document: ', error);
    }
  };

  useEffect(() => {
    if (mobileNumber) {
      fetchReferralAmount(mobileNumber);
    }
  }, [mobileNumber]);

  const ReferralON = () => {
    setReferralBackgroundColor('#ccc')
    setCoinsBackgroundColor('white')
    console.log('function Referral')
  }

  const CoinsON = () => {
    console.log('function Coins')
    setReferralBackgroundColor('white')
    setCoinsBackgroundColor('#ccc')
  }
  return (
    <View style={{ height: ScreenHeight, width: ScreenWidth }}>
      <View style={{ height: ScreenHeight, width: ScreenWidth }}>
        <View style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
          <Image style={{ height: 50, width: 50 }} source={require('../assets/images/walletImage.png')} />
          <Text style={{ fontSize: 20 }}>Wallet</Text>
        </View>

        <View style={{display:'flex', flexDirection:'row'}} >
          <TouchableOpacity onPress={ReferralON} style={{borderWidth:0.5, backgroundColor:referralBackgroundColor}} >
            <View style={{width:ScreenWidth/2, display:'flex', alignItems:'center', justifyContent:'center', height:40}} ><Text style={{fontSize:16}} >Referral: ₹{referralAmount}</Text></View>
          </TouchableOpacity>
          <TouchableOpacity onPress={CoinsON} style={{borderWidth:0.5, backgroundColor:coinsBackgroundColor}} >
            <View style={{ width: ScreenWidth / 2, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 40 }} ><Text style={{ fontSize: 16 }} >Coins: {Coins}</Text></View>
              </TouchableOpacity>
        </View>
        
        {/* Display the referralAmount */}
        { referralBackgroundColor === '#ccc' && <View style={{padding: 10}}>
          <Text style={{ fontSize: 18 }}>Referral: ₹{referralAmount}</Text>
        </View>}
        
        { coinsBackgroundColor === '#ccc' && <View style={{padding: 10}}>
          <Text style={{ fontSize: 18 }}>Coins: {Coins}</Text>
        </View> }



        <BottomNavBar mobileNumber={mobileNumber} />
      </View>
    </View>
  );
};

export default Wallet;

const styles = StyleSheet.create({});