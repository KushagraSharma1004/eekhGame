import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity, Alert } from 'react-native';
import React, { useState } from 'react';
import { useRouter } from 'expo-router';
import { doc, getDoc } from 'firebase/firestore'; // Import necessary Firestore functions
import { db } from './firebaseConfig'; // Import Firebase configuration

const ForgotPassword = () => {
  const screenWidth = Dimensions.get('window').width;
  const screenHeight = Dimensions.get('window').height;
  const router = useRouter();

  const [otp, setOtp] = useState(''); // State to hold the entered OTP
  const [mobileNumber, setMobileNumber] = useState(''); // State to hold the mobile number (to fetch the corresponding OTP)

  const goToSignUp = () => {
    router.push('./SignUp');
  };

  const handleOtpSubmit = async () => {
    if (otp.length !== 6) {
      Alert.alert('Error', 'Please enter a valid 6-digit OTP');
      return;
    }

    try {
      const userDoc = doc(db, 'users', mobileNumber); // Get the user document based on mobile number
      const userSnapshot = await getDoc(userDoc);

      if (userSnapshot.exists()) {
        const userData = userSnapshot.data();
        if (userData.otp === otp) {
          Alert.alert('Success', 'OTP verified successfully!');
          router.push('./CreateNewPassword'); // Proceed to create new password
        } else {
          Alert.alert('Error', 'Invalid OTP. Please try again.');
        }
      } else {
        Alert.alert('Error', 'User not found. Please check the mobile number.');
      }
    } catch (error) {
      console.error('Error verifying OTP:', error);
      Alert.alert('Error', 'Failed to verify OTP');
    }
  };

  const goToHome = () => {
    router.push('./Home');
  };

  const resendOtp = async () => {
    // Logic to resend OTP to the user's email
    // This could involve regenerating and resending the OTP similar to the original sign-up process
    Alert.alert('Info', 'OTP has been resent to your email.');
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 18, marginBottom: 20 }}>Enter OTP</Text>
      <TextInput
        placeholder='Mobile Number'
        style={{
          height: 50,
          width: screenWidth - 100,
          borderWidth: 3,
          padding: 10,
          borderRadius: 7,
          marginBottom: 10,
        }}
        keyboardType="numeric"
        maxLength={10}
        onChangeText={setMobileNumber}
      />
      <TextInput
        placeholder='Enter OTP'
        style={{
          height: 50,
          width: screenWidth - 100,
          borderWidth: 3,
          padding: 10,
          borderRadius: 7,
          marginBottom: 10,
        }}
        keyboardType="numeric"
        maxLength={6}
        onChangeText={setOtp}
      />
      <TouchableOpacity
        onPress={handleOtpSubmit}
        style={{
          width: screenWidth - 100,
          borderWidth: 3,
          borderRadius: 7,
          height: 50,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: 'black',
        }}
      >
        <Text style={{ fontSize: 16, color: 'white' }}>Submit</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={resendOtp} style={{ width: screenWidth - 100, marginTop: 10 }}>
        <Text style={{ textAlign: 'right', fontSize: 14, color: 'blue' }}>Resend OTP</Text>
      </TouchableOpacity>
    </View>
  );
};

export default ForgotPassword;

const styles = StyleSheet.create({});
