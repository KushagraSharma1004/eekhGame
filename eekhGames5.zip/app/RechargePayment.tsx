import React, { useEffect, useState } from 'react';
import { View, Text, Button, Alert } from 'react-native';
import { doc, getDoc, updateDoc, addDoc, collection } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { db } from './firebaseConfig'; // Your Firestore config

const RechargePayment = () => {
    const router = useRouter();
    const { mobileNumber, price, duration } = router.query; // Get the passed query params

    const [referralAmount, setReferralAmount] = useState(0);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Fetch user's referralAmount from Firestore
        const fetchReferralAmount = async () => {
            const userRef = doc(db, 'users', mobileNumber);
            const userDoc = await getDoc(userRef);
            if (userDoc.exists()) {
                setReferralAmount(userDoc.data().referralAmount || 0);
            } else {
                Alert.alert('Error', 'User does not exist.');
            }
            setLoading(false);
        };

        fetchReferralAmount();
    }, [mobileNumber]);

    const handleReferralPayment = async () => {
        if (referralAmount < price) {
            Alert.alert('Error', 'Insufficient referral balance.');
            return;
        }

        try {
            const newReferralAmount = referralAmount - price;
            const expiryDate = new Date(Date.now() + duration * 24 * 60 * 60 * 1000); // Current date + duration in milliseconds
            const userRef = doc(db, 'users', mobileNumber);

            // Update referral balance and recharge balance in Firestore
            await updateDoc(userRef, {
                referralAmount: newReferralAmount,
                rechargeExpiry: expiryDate, // Update expiry date
                rechargeBalance: price, // Update balance
            });

            // Log recharge history
            await addDoc(collection(db, 'recharges'), {
                mobileNumber,
                amount: price,
                duration,
                expiryDate,
                createdAt: new Date(),
            });

            Alert.alert('Recharge Successful', `You have recharged for ${duration} days. Amount: ₹${price}`);
        } catch (error) {
            console.error('Error processing referral payment:', error);
            Alert.alert('Error', 'Failed to process payment. Please try again.');
        }
    };

    const handlePhonePePayment = () => {
        // Implement PhonePe payment logic here
        Alert.alert('PhonePe payment selected.');
        // Redirect to PhonePe gateway for payment handling.
    };

    if (loading) {
        return <Text>Loading...</Text>;
    }

    return (
        <View>
            <Text>Recharge Payment</Text>
            <Text>Mobile Number: {mobileNumber}</Text>
            <Text>Amount: ₹{price}</Text>
            <Text>Duration: {duration} days</Text>

            <Text>Referral Balance: ₹{referralAmount}</Text>

            {/* Payment Options */}
            <Button title="Pay with Referral Balance" onPress={handleReferralPayment} />
            <Button title="Pay with PhonePe" onPress={handlePhonePePayment} />
        </View>
    );
};

export default RechargePayment;
