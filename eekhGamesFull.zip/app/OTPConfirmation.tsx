import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React from 'react'
import { useRouter } from 'expo-router';
import { useRoute } from '@react-navigation/native';
const OTPConfirmation = () => {
    const router = useRouter();
    const route = useRoute();
    const mobileNumber = route.params?.mobileNumber;
    const goToSignUp = () => {
    router.push(`./SignUp?mobileNumber=${mobileNumber}`);
  };
  return (
    <View>
          <Text>OTPConfirmation</Text>
          <TouchableOpacity onPress={goToSignUp} >
              <Text>go</Text>
          </TouchableOpacity>
    </View>
  )
}

export default OTPConfirmation

const styles = StyleSheet.create({})