import { StyleSheet, Text, View, Image, TouchableOpacity, Button } from 'react-native'
import React, { useEffect, useState } from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import BottomNavBar from './BottomNavBar'
import { useRoute } from '@react-navigation/native'
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { app } from './firebaseConfig'; // Ensure your Firebase app is initialized here
import MyBeatScoreHistory from './MyBeatScoreHistory'
import MyBeat2ScoreHistory from './MyBeat2ScoreHistory'
const Wallet = () => {
  const [referralAmount, setReferralAmount] = useState(0);  // State to hold referralAmount
  const [Coins, setCoins] = useState(0);
  const [MyBeatScore, setMyBeatScore] = useState(0);
  const [MyBeat2Score, setMyBeat2Score] = useState(0);
  const route = useRoute();
  const mobileNumber = route.params?.mobileNumber;
  const [referralBackgroundColor, setReferralBackgroundColor] = useState('#ccc')
  const [coinsBackgroundColor, setCoinsBackgroundColor] = useState('white')
  const [myBeatScoreHistory, setMyBeatScoreHistory] = useState(false)
  const [myBeat2ScoreHistory, setMyBeat2ScoreHistory] = useState(false)
  
  const fetchReferralAmount = async (mobileNumber) => {
    try {
      const db = getFirestore(app);
      const docRef = doc(db, 'users', mobileNumber); // Assuming your Firestore structure has a collection 'users' with mobile numbers as document IDs
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const userData = docSnap.data();
        setReferralAmount(userData.referralAmount || 0); // Update referralAmount state with the fetched value
        setCoins(userData.Coins || 0)
        setMyBeatScore(userData.MyBeatScore)
        setMyBeat2Score(userData.MyBeat2Score)
      } else {
        console.log('No such document!');
      }
    } catch (error) {
      console.error('Error fetching document: ', error);
    }
  };

  useEffect(() => {
    if (mobileNumber) {
      fetchReferralAmount(mobileNumber);
    }
  }, [mobileNumber]);

  const ReferralON = () => {
    setReferralBackgroundColor('#ccc')
    setCoinsBackgroundColor('white')
    console.log('function Referral')
  }

  const CoinsON = () => {
    console.log('function Coins')
    setReferralBackgroundColor('white')
    setCoinsBackgroundColor('#ccc')
  } 

  const openMyBeatScoreHistory = () => {
    if (myBeatScoreHistory) {
      setMyBeatScoreHistory(false)
    } else {
      setMyBeatScoreHistory(true)
      setMyBeat2ScoreHistory(false)
    }
    
  }

  const openMyBeat2ScoreHistory = () => {
    if (myBeat2ScoreHistory) {
      setMyBeat2ScoreHistory(false)
    } else {
      setMyBeat2ScoreHistory(true)
      setMyBeatScoreHistory(false)
    }
    
  }
  
  return (
    <View style={{ height: ScreenHeight, width: ScreenWidth }}>
      <View style={{ height: ScreenHeight, width: ScreenWidth }}>
        <View style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
          <Image style={{ height: 50, width: 50 }} source={require('../assets/images/walletImage.png')} />
          <Text style={{ fontSize: 20 }}>Wallet</Text>
        </View>

        <View style={{display:'flex', flexDirection:'row'}} >
          <TouchableOpacity onPress={ReferralON} style={{borderWidth:0.5, backgroundColor:referralBackgroundColor}} >
            <View style={{width:ScreenWidth/2, display:'flex', alignItems:'center', justifyContent:'center', height:40}} ><Text style={{fontSize:16}} >Referral: ₹{referralAmount}</Text></View>
          </TouchableOpacity>
          <TouchableOpacity onPress={CoinsON} style={{borderWidth:0.5, backgroundColor:coinsBackgroundColor}} >
            <View style={{ width: ScreenWidth / 2, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 40 }} ><Text style={{ fontSize: 16 }} >Coins: {Coins}</Text></View>
              </TouchableOpacity>
        </View>
        
        {/* Display the referralAmount */}
        { referralBackgroundColor === '#ccc' && <View style={{padding: 10}}>
          <Text style={{ fontSize: 18 }}>Referral: ₹{referralAmount}</Text>
        </View>}
        
        { coinsBackgroundColor === '#ccc' && <View style={{padding: 10, gap:5}}>
          <TouchableOpacity onPress={openMyBeatScoreHistory} style={{ display: 'flex', flexDirection: 'row', gap: 10, alignItems: 'center' }}>
            <View style={{display:'flex', flexDirection:'row'}} >
            <View style={{width:180}} ><Text style={{ fontSize: 18 }} >My Beat Score</Text></View>
            <View style={{width:10, display:'flex', alignItems:'center', justifyContent:'center'}} ><Text style={{ fontSize: 18 }} >:</Text></View>
            <View style={{width:100, display:'flex', justifyContent:'center'}} ><Text style={{ fontSize: 18, position:'absolute', right:0}} >{MyBeatScore || 0}</Text></View>
            </View>
            {myBeatScoreHistory && <View style={{ borderWidth: 3, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 28.8, width: 28.8, borderColor: 'blue' }} >
              <Image style={{ height: 25, width: 25}} source={require('../assets/images/arrowDown.png')} ></Image>
            </View>}
            { !myBeatScoreHistory && <View style={{borderWidth:1, display:'flex', alignItems:'center', justifyContent:'center', height:25.8, width:25.8}} >
              <Image style={{ height: 25, width: 25}} source={require('../assets/images/arrowRight.png')} ></Image>
            </View>}
          </TouchableOpacity>

          {myBeatScoreHistory && <MyBeatScoreHistory mobileNumber={mobileNumber} />}

          <TouchableOpacity onPress={openMyBeat2ScoreHistory} style={{ display: 'flex', flexDirection: 'row', gap: 10, alignItems: 'center'}}>
            <View style={{display:'flex', flexDirection:'row'}} >
            <View style={{width:180}} ><Text style={{ fontSize: 18 }} >My Beat 2 Score</Text></View>
            <View style={{width:10, display:'flex', alignItems:'center', justifyContent:'center'}} ><Text style={{ fontSize: 18 }} >:</Text></View>
            <View style={{width:100, display:'flex', justifyContent:'center'}} ><Text style={{ fontSize: 18, position:'absolute', right:0}} >{MyBeat2Score || 0}</Text></View>
            </View>
            {myBeat2ScoreHistory && <View style={{ borderWidth: 3, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 28.8, width: 28.8, borderColor: 'blue' }} >
              <Image style={{ height: 25, width: 25}} source={require('../assets/images/arrowDown.png')} ></Image>
            </View>}
            { !myBeat2ScoreHistory && <View style={{borderWidth:1, display:'flex', alignItems:'center', justifyContent:'center', height:25.8, width:25.8}} >
              <Image style={{ height: 25, width: 25}} source={require('../assets/images/arrowRight.png')} ></Image>
            </View>}
          </TouchableOpacity>
          {myBeat2ScoreHistory && <MyBeat2ScoreHistory mobileNumber={mobileNumber} />}
        </View>}
        
        
        


        <BottomNavBar mobileNumber={mobileNumber} />
      </View>
    </View>
  );
};

export default Wallet;

const styles = StyleSheet.create({});