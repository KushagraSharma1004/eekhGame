import { StyleSheet, Text, View, TextInput, Dimensions, TouchableOpacity } from 'react-native'
import React from 'react'
import { Link, useRouter } from 'expo-router'
import './main'
const CreateNewPassword = () => {
    const screenWidth = Dimensions.get('window').width;
    const screenHeight = Dimensions.get('window').height;
    const router = useRouter();

  const goToLogin = () => {
    router.push('./');
  };
  return (
    <View>
          <View style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', height: screenHeight, width: screenWidth, gap: 10, alignItems: 'center' }} >
              
              <Text style={{ fontSize: 20, width:screenWidth-100}} >Create New Password</Text>
              <TextInput placeholder='New Password' style={{ height: 50, width: screenWidth - 100, borderWidth: 3, padding: 10, borderRadius: 7 }} secureTextEntry={true}></TextInput>
              <TextInput placeholder='Re-Enter New Password' style={{ height: 50, width: screenWidth - 100, borderWidth: 3, padding: 10, borderRadius: 7 }}></TextInput>
              <TouchableOpacity onPress={goToLogin} style={{ width: screenWidth - 100, borderWidth:3, borderRadius:7, height:50, alignItems:'center', justifyContent:'center', backgroundColor:'black', display:'flex' }}>
                  <Text style={{fontSize:16, color:'white'}} >Confirm</Text>
              </TouchableOpacity>

              
          </View>
      </View>
  )
}

export default CreateNewPassword

const styles = StyleSheet.create({})