import { StyleSheet, Text, View } from 'react-native'
import React, {useEffect, useState} from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import BottomNavBar from './BottomNavBar'
import './main'
const Referral = () => {
  const [mobileNumber, setMobileNumber] = useState('');

  useEffect(() => {
    // Simulating the URL you provided
    const url = 'http://localhost:8081/Home?mobileNumber=9352000360';

    // Parsing the URL
    const parsedUrl = new URL(url);
    const mobileNumberParam = parsedUrl.searchParams.get('mobileNumber');

    // Setting the mobile number in state
    setMobileNumber(mobileNumberParam);
  }, []);
  return (
    <View >
          <View style={{ height: ScreenHeight, width: ScreenWidth }} >
              <Text>Referral</Text>
                <BottomNavBar mobileNumber/>
           </View>
          
    </View>
  )
}

export default Referral

const styles = StyleSheet.create({})