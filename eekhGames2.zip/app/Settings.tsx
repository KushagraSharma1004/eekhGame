import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import BottomNavBar from './BottomNavBar'
import './main'
const Settings = () => {
  return (
    <View >
          <View style={{ height: ScreenHeight, width: ScreenWidth }} >
              <Text>Settings</Text>
                <BottomNavBar/>
           </View>
          
    </View>
  )
}

export default Settings

const styles = StyleSheet.create({})