import { StyleSheet, Text, View, Image, TouchableOpacity, Animated } from 'react-native'
import React,{ useState, useEffect, useRef } from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import { router, useRouter } from 'expo-router'
import Menu from './Menu'
import BottomNavBar from './BottomNavBar'
import './main'
import { useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome5';
const Home = () => {
  const bounceValue = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const bounce = () => {
      Animated.sequence([
        Animated.timing(bounceValue, {
          toValue: 1.1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(bounceValue, {
          toValue: 2,
          duration: 500,
          useNativeDriver: true,
        }),
      ]).start(() => bounce());
    };

    bounce();
  }, [bounceValue]);
  const route = useRoute();
  const router = useRouter()
  
  const mobileNumber = route.params?.mobileNumber;
  // console.log(mobileNumber)

  const openGames = () => {
    router.push(`./Games?mobileNumber=${mobileNumber}`)
  }
  return (
      <View >
          
      <View style={{ height: ScreenHeight, width: ScreenWidth, padding: 10 }} >
        <View style={{height:ScreenHeight-200, padding:0}} >
        <TouchableOpacity onPress={openGames} style={{display:'flex', flexDirection:'column', borderWidth:1, width:73, height:70, alignItems:'center', justifyContent:'center', borderRadius:10 }} >
          <Image style={{height:40, width:70}} source={require('../assets/images/gameController.jpg')} ></Image>
          <Text style={{fontSize:13}} >Games</Text>
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity style={{backgroundColor:'#c9c9c4', height:60, width:ScreenWidth-20, borderRadius:10, display:'flex', flexDirection:'row', alignItems:'center', justifyContent:'space-evenly', marginTop:10}} >
         <Animated.View style={{ transform: [{ scale: bounceValue }]}}>
        <Icon name="gift" size={30} color="black" />
          </Animated.View>
          <View style={{display:'flex', flexDirection:'column'}} >
            <Text style={{color:'black'}} >Refer and earn</Text>
            <Text style={{color:'grey', fontSize:10}} >Earn unlimited* from every referral</Text>
          </View>

          <View style={{height:25, width:90, backgroundColor:'black', borderRadius:7, display:'flex', alignItems:'center', justifyContent:'center'}} ><Text style={{color:'white', fontSize:14}} >Refer Now</Text></View>
        </TouchableOpacity>
        
        
              
          </View>
          <BottomNavBar mobileNumber={ mobileNumber} />
          
    </View>
  )
}

export default Home

const styles = StyleSheet.create({})