import { StyleSheet, Text, View, Dimensions, ActivityIndicator, Alert, Linking, TouchableOpacity, Clipboard, ToastAndroid } from 'react-native';
import React, { useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from './firebaseConfig'; // Import your Firebase configuration
import BottomNavBar from './BottomNavBar';

// Import useAuth
 import './main'
import { useRoute } from '@react-navigation/native';
const Profile = () => {
  const route = useRoute();
  const mobileNumber = route.params?.mobileNumber;
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const screenHeight = Dimensions.get('window').height;
  const screenWidth = Dimensions.get('window').width;

  useEffect(() => {
  const fetchUserData = async () => {
    // if (!mobileNumber) {
    //   Alert.alert('Error', 'Mobile number is not available');
    //   setLoading(false);
    //   return;
    // }

    try {
      const userDoc = doc(db, 'users', mobileNumber);
      const userSnapshot = await getDoc(userDoc);

      // Debugging log to see what userSnapshot contains
      console.log('User Snapshot:', userSnapshot.data());

      if (userSnapshot.exists()) {
        const data = userSnapshot.data();
        
        // Debugging to check the type of data and specific fields
        console.log('User Data:', data);
        
        if (typeof data.name !== 'string') {
          console.error('Expected name to be a string, but got:', data.name);
        }

        setUserData(data);
      } else {
        Alert.alert('Error', 'No user found with this mobile number');
      }
    } catch (error) {
      // console.error('Error fetching user data:', error);
      // Alert.alert('Error', 'Failed to fetch user data');
    } finally {
      setLoading(false);
    }
  };

  fetchUserData();
}, [mobileNumber]); // Runs when mobileNumber changes
 // Runs when mobileNumber changes

  if (loading) {
    return <ActivityIndicator size="large" color="blue" style={styles.loadingIndicator} />;
  }

  const copyToClipboard = () => {
    Clipboard.setString(`${userData.selfReferralCode}`);
    ToastAndroid.show("Referral code Copied", ToastAndroid.LONG);
  };
  

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile</Text>
      {userData ? (
        <View style={styles.userDataContainer}>
          <Text style={styles.label}>Name: {userData.name || 'No Name'}</Text>
          <Text style={styles.label}>Mobile Number: {userData.mobileNumber}</Text>
          <Text style={styles.label}>Address: {userData.address}</Text>
          <Text style={styles.label}>Email: {userData.email}</Text>
          <Text style={styles.label}>Instagram Id: {userData.instagramId}</Text>
          <Text style={styles.label}>Facebook Id: {userData.facebookId}</Text>
          <View style={{display:'flex', flexDirection:'row', alignItems:'center', gap:10}} >
          <Text style={styles.label}>Referral Code: {userData.selfReferralCode}</Text>
          <TouchableOpacity onPress={copyToClipboard} style={{display:'flex', flexDirection:'row', gap:10, alignItems:'center', borderWidth:0.5, width:40, borderRadius:3, justifyContent:'center', backgroundColor:'black', height:20,marginTop:3}} >
            <Text style={{fontSize:13, color:'white', marginTop:-3}} >Copy</Text>
            </TouchableOpacity>
          </View>
          {/* Add more fields as needed */}
          {/* Be cautious about displaying sensitive information */}
        </View>
      ) : (
        <Text style={styles.noDataText}>No user data available.</Text>
      )}
      <BottomNavBar mobileNumber={mobileNumber}/>
    </View>
  );
};

export default Profile;

const styles = StyleSheet.create({
  container: {
    height: '100%',
    width: '100%',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  userDataContainer: {
    marginTop: 20,
  },
  label: {
    fontSize: 18,
    marginVertical: 5,
  },
  loadingIndicator: {
    marginTop: 20,
  },
  noDataText: {
    marginTop: 20,
    fontSize: 18,
    color: 'red',
  },
});
