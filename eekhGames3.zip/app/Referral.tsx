import { StyleSheet, Text, View } from 'react-native'
import React, {useEffect, useState} from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import BottomNavBar from './BottomNavBar'
import './main'
import { useRoute } from '@react-navigation/native';
const Referral = () => {
  const route = useRoute();
  const mobileNumber = route.params?.mobileNumber;
  return (
    <View >
          <View style={{ height: ScreenHeight, width: ScreenWidth }} >
              <Text>Referral</Text>
        <BottomNavBar mobileNumber={ mobileNumber } />
           </View>
          
    </View>
  )
}

export default Referral

const styles = StyleSheet.create({})