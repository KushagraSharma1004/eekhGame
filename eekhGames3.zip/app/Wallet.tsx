import { StyleSheet, Text, View, Image, TouchableOpacity, Button, FlatList, Alert } from 'react-native'
import React, { useEffect, useState } from 'react'
import { ScreenHeight, ScreenWidth } from 'react-native-elements/dist/helpers'
import BottomNavBar from './BottomNavBar'
import { useRoute } from '@react-navigation/native'
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { app, db } from './firebaseConfig'; // Ensure your Firebase app is initialized here
import MyBeatScoreHistory from './MyBeatScoreHistory'
import MyBeat2ScoreHistory from './MyBeat2ScoreHistory'
import RechargeOptions from './RechargeOptions'
import { updateDoc, collection, addDoc, query, where, getDocs, onSnapshot } from 'firebase/firestore';
const Wallet = () => {
  const [referralAmount, setReferralAmount] = useState(0);  // State to hold referralAmount
  const [Coins, setCoins] = useState(0);
  const [rechargeBalance, setrechargeBalance] = useState(0);
  const [MyBeatScore, setMyBeatScore] = useState(0);
  const [MyBeat2Score, setMyBeat2Score] = useState(0);
  const route = useRoute();
  const mobileNumber = route.params?.mobileNumber;
  const [referralBackgroundColor, setReferralBackgroundColor] = useState('#ccc')
  const [coinsBackgroundColor, setCoinsBackgroundColor] = useState('white')
  const [rechargeBackgroundColor, setRechargeBackgroundColor] = useState('white')
  const [myBeatScoreHistory, setMyBeatScoreHistory] = useState(false)
  const [myBeat2ScoreHistory, setMyBeat2ScoreHistory] = useState(false)
  const [rechargeOptionsVisible, setRechargeOptionsVisible] = useState(false)
  const [rechargeHistory, setRechargeHistory] = useState([]);
  const fetchReferralAmount = async (mobileNumber) => {
    try {
      const db = getFirestore(app);
      const docRef = doc(db, 'users', mobileNumber); // Assuming your Firestore structure has a collection 'users' with mobile numbers as document IDs
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const userData = docSnap.data();
        setReferralAmount(userData.referralAmount || 0); // Update referralAmount state with the fetched value
        setCoins(userData.Coins || 0)
        setrechargeBalance(userData.rechargeBalance)
        setMyBeatScore(userData.MyBeatScore)
        setMyBeat2Score(userData.MyBeat2Score)
      } else {
        console.log('No such document!');
      }
    } catch (error) {
      console.error('Error fetching document: ', error);
    }
  };

  useEffect(() => {
    if (mobileNumber) {
      fetchReferralAmount(mobileNumber);
    }
  }, [mobileNumber]);

  const ReferralON = () => {
    setReferralBackgroundColor('#ccc')
    setCoinsBackgroundColor('white')
    setRechargeBackgroundColor('white')
    console.log('function Referral')
  }

  const CoinsON = () => {
    console.log('function Coins')
    setReferralBackgroundColor('white')
    setCoinsBackgroundColor('#ccc')
    setRechargeBackgroundColor('white')
  } 
  const RechargeON = () => {
    console.log('function Recharge')
    setReferralBackgroundColor('white')
    setCoinsBackgroundColor('white')
    setRechargeBackgroundColor('#ccc')
  } 

  const openMyBeatScoreHistory = () => {
    if (myBeatScoreHistory) {
      setMyBeatScoreHistory(false)
    } else {
      setMyBeatScoreHistory(true)
      setMyBeat2ScoreHistory(false)
    }
    
  }

  const openMyBeat2ScoreHistory = () => {
    if (myBeat2ScoreHistory) {
      setMyBeat2ScoreHistory(false)
    } else {
      setMyBeat2ScoreHistory(true)
      setMyBeatScoreHistory(false)
    }
    
  }

  const changeVisiblityOfRechargeOptions = () => {
    if (rechargeOptionsVisible) {
      setRechargeOptionsVisible(false)
    } else {
      setRechargeOptionsVisible(true)
    }
  }

  useEffect(() => {
        const fetchRechargeHistory = () => {
            const q = query(collection(db, 'recharges'), where('mobileNumber', '==', mobileNumber));
            const unsubscribe = onSnapshot(q, (querySnapshot) => {
                const history = [];
                querySnapshot.forEach((doc) => {
                    history.push({ id: doc.id, ...doc.data() });
                });

                // Sort the history by createdAt in descending order to show the latest first
                const sortedHistory = history.sort((a, b) => b.createdAt.toMillis() - a.createdAt.toMillis());
                setRechargeHistory(sortedHistory);
            }, (error) => {
                console.error('Error fetching recharge history:', error);
                Alert.alert('Error', 'Failed to fetch recharge history.');
            });

            return () => unsubscribe(); // Cleanup subscription
        };

        fetchRechargeHistory();
  }, [mobileNumber]);
  
  const formatDateTime = (date) => {
        return date.toDate().toLocaleString(); // Formats to local date and time string
    };

    const getRemainingTime = (expiryDate) => {
        const now = new Date();
        const remainingTime = expiryDate.toDate() - now; // Calculate remaining time in milliseconds

        // Convert remaining time to days, hours, minutes, seconds
        const days = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
        const hours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);

        return <Text>{days}d {hours}h {minutes}m {seconds}s</Text>; // Format remaining time
    };

    const renderItem = ({ item }) => (
        <View style={{
            padding: 10,
            borderWidth: 1,
            borderColor: '#ccc',
            borderRadius: 5,
            marginBottom: 5,
        }}>
            <Text style={{ fontSize: 16 }}>Amount: ₹{item.amount}</Text>
            <Text style={{ fontSize: 16 }}>Duration: {item.duration} Days</Text>
            <Text style={{ fontSize: 16 }}>Expiry Date: {formatDateTime(item.expiryDate)}</Text>
            <Text style={{ fontSize: 16 }}>Recharge Date: {formatDateTime(item.createdAt)}</Text>
            <Text style={{ fontSize: 16 }}>Time Remaining: {getRemainingTime(item.expiryDate)}</Text> 
        </View>
    );
  return (
    <View style={{ height: ScreenHeight, width: ScreenWidth }}>
      <View style={{ height: ScreenHeight, width: ScreenWidth }}>
        <View style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
          <Image style={{ height: 50, width: 50 }} source={require('../assets/images/walletImage.png')} />
          <Text style={{ fontSize: 20 }}>Wallet</Text>
        </View>

        <View style={{display:'flex', flexDirection:'row'}} >
          <TouchableOpacity onPress={ReferralON} style={{borderWidth:0.5, backgroundColor:referralBackgroundColor}} >
            <View style={{width:ScreenWidth / 3, display:'flex', alignItems:'center', justifyContent:'center', height:40}} ><Text style={{fontSize:12}} >Referral: ₹{referralAmount}</Text></View>
          </TouchableOpacity>
          <TouchableOpacity onPress={CoinsON} style={{borderWidth:0.5, backgroundColor:coinsBackgroundColor}} >
            <View style={{ width: ScreenWidth / 3, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 40 }} ><Text style={{ fontSize: 12 }} >Coins: {Coins}</Text></View>
          </TouchableOpacity>
          <TouchableOpacity onPress={RechargeON} style={{borderWidth:0.5, backgroundColor:rechargeBackgroundColor}} >
            <View style={{ width: ScreenWidth / 3, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 40 }} ><Text style={{ fontSize: 12 }} >Recharge Bal: {rechargeBalance}</Text></View>
              </TouchableOpacity>
        </View>
        
        {/* Display the referralAmount */}
        { referralBackgroundColor === '#ccc' && <View style={{padding: 10}}>
          <Text style={{ fontSize: 18 }}>Referral: ₹{referralAmount}</Text>
        </View>}

        {rechargeBackgroundColor === '#ccc' && <View style={{ padding: 10 }}>
          <View style={{display:'flex', width:'100%', justifyContent:'center', alignItems:'flex-end', position:'absolute', zIndex:99, top:10,right:2}} >
          <TouchableOpacity onPress={changeVisiblityOfRechargeOptions} style={{backgroundColor:'black', borderRadius:7, width:125, height:28, display:'flex', alignItems:'center', justifyContent:'center'}} >
            <Text style={{ fontSize: 13, color:'white' }}>Recharge Now</Text>
            </TouchableOpacity>

            {rechargeOptionsVisible&&<RechargeOptions mobileNumber={mobileNumber}/>}
          </View>
          <Text style={{ marginBottom: 10, fontSize: 13 }}>Recharge History</Text>
          <FlatList
                data={rechargeHistory}
                renderItem={renderItem}
                keyExtractor={item => item.id}
                style={{ maxHeight: ScreenHeight - 210 }} // Ensure the FlatList doesn't overflow
            />
        </View>}

        
        { coinsBackgroundColor === '#ccc' && <View style={{padding: 10, gap:5}}>
          <TouchableOpacity onPress={openMyBeatScoreHistory} style={{ display: 'flex', flexDirection: 'row', gap: 10, alignItems: 'center' }}>
            <View style={{display:'flex', flexDirection:'row'}} >
            <View style={{width:180}} ><Text style={{ fontSize: 18 }} >My Beat Score</Text></View>
            <View style={{width:10, display:'flex', alignItems:'center', justifyContent:'center'}} ><Text style={{ fontSize: 18 }} >:</Text></View>
            <View style={{width:100, display:'flex', justifyContent:'center'}} ><Text style={{ fontSize: 18, position:'absolute', right:0}} >{MyBeatScore || 0}</Text></View>
            </View>
            {myBeatScoreHistory && <View style={{ borderWidth: 3, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 28.8, width: 28.8, borderColor: 'blue' }} >
              <Image style={{ height: 25, width: 25}} source={require('../assets/images/arrowDown.png')} ></Image>
            </View>}
            { !myBeatScoreHistory && <View style={{borderWidth:1, display:'flex', alignItems:'center', justifyContent:'center', height:25.8, width:25.8}} >
              <Image style={{ height: 25, width: 25}} source={require('../assets/images/arrowRight.png')} ></Image>
            </View>}
          </TouchableOpacity>

          {myBeatScoreHistory && <MyBeatScoreHistory mobileNumber={mobileNumber} />}

          <TouchableOpacity onPress={openMyBeat2ScoreHistory} style={{ display: 'flex', flexDirection: 'row', gap: 10, alignItems: 'center'}}>
            <View style={{display:'flex', flexDirection:'row'}} >
            <View style={{width:180}} ><Text style={{ fontSize: 18 }} >My Beat 2 Score</Text></View>
            <View style={{width:10, display:'flex', alignItems:'center', justifyContent:'center'}} ><Text style={{ fontSize: 18 }} >:</Text></View>
            <View style={{width:100, display:'flex', justifyContent:'center'}} ><Text style={{ fontSize: 18, position:'absolute', right:0}} >{MyBeat2Score || 0}</Text></View>
            </View>
            {myBeat2ScoreHistory && <View style={{ borderWidth: 3, display: 'flex', alignItems: 'center', justifyContent: 'center', height: 28.8, width: 28.8, borderColor: 'blue' }} >
              <Image style={{ height: 25, width: 25}} source={require('../assets/images/arrowDown.png')} ></Image>
            </View>}
            { !myBeat2ScoreHistory && <View style={{borderWidth:1, display:'flex', alignItems:'center', justifyContent:'center', height:25.8, width:25.8}} >
              <Image style={{ height: 25, width: 25}} source={require('../assets/images/arrowRight.png')} ></Image>
            </View>}
          </TouchableOpacity>
          {myBeat2ScoreHistory && <MyBeat2ScoreHistory mobileNumber={mobileNumber} />}
        </View>}
        
        
        


        <BottomNavBar mobileNumber={mobileNumber} />
      </View>
    </View>
  );
};

export default Wallet;

const styles = StyleSheet.create({});