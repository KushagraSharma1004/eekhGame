import { StyleSheet, Text, TouchableOpacity, View, Alert, FlatList } from 'react-native';
import React, { useState, useEffect } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { db } from './firebaseConfig'; // Import your Firebase configuration
import { doc, updateDoc, collection, addDoc, query, where, getDocs, getDoc } from 'firebase/firestore';

const RechargeOptions = ({ mobileNumber }) => {
    const [selectedOption, setSelectedOption] = useState('365');
    const [rechargeOptionsVisible, setRechargeOptionsVisible] = useState(true)

    const options = [
        { id: '30', label: '30 Days', price: 120, duration: 30 },
        { id: '90', label: '90 Days', price: 340, duration: 90 },
        { id: '180', label: '180 Days', price: 650, duration: 180 },
        { id: '365', label: '365 Days', price: 1200, duration: 365 },
    ];

    
    const handleSelect = (id) => {
        setSelectedOption(id);
    };

    const handleConfirm = async () => {
        setRechargeOptionsVisible(false)
    if (!selectedOption) {
        Alert.alert('Please select a recharge option.');
        return;
    }

    const selected = options.find(option => option.id === selectedOption);
    const { price, duration } = selected;

    // Calculate the expiry date
    const expiryDate = new Date(Date.now() + duration * 24 * 60 * 60 * 1000); // Current date + duration in milliseconds

    // Update the recharge balance in Firestore
    const userRef = doc(db, 'users', mobileNumber);

    try {
        const userDoc = await getDoc(userRef);
            let currentBalance = userDoc.exists() ? (userDoc.data().rechargeBalance || 0) : 0;
        await updateDoc(userRef, {
            rechargeBalance: currentBalance + price, // Update balance
            rechargeExpiry: expiryDate // Set expiry date
        });

        // Save recharge history
        await addDoc(collection(db, 'recharges'), {
            mobileNumber,
            amount: price,
            duration,
            expiryDate: expiryDate, // Set expiry date
            createdAt: new Date() // Store creation time
        });

        Alert.alert('Recharge Successful', `You have recharged for ${duration} days. Amount: ₹${price}`);
        // Refresh history
        
    } catch (error) {
        console.error('Error updating recharge balance:', error);
        Alert.alert('Error', 'Failed to recharge. Please try again.');
    }
};


    return (
        <View style={{ borderWidth: 1, borderRadius: 7, maxHeight: 400, width: '50%', padding: 10, marginTop: 2 , backgroundColor:'white'}}>
            <Text style={{ fontSize: 12 }}>Recharge Options</Text>
            <View style={{ borderWidth: 1, borderColor: '#ccc', marginTop: 2 }} />
            <View style={{ marginTop: 10, gap: 10 }}>
                {options.map((option) => (
                    <View key={option.id} style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
                        <TouchableOpacity
                            style={{
                                width: 20,
                                height: 20,
                                borderWidth: 2,
                                borderColor: '#000',
                                justifyContent: 'center',
                                alignItems: 'center',
                                backgroundColor: selectedOption === option.id ? 'black' : 'transparent',
                            }}
                            onPress={() => handleSelect(option.id)}
                        >
                            {selectedOption === option.id && <Ionicons name="checkmark" size={15} color="white" />}
                        </TouchableOpacity>
                        <View style={{ display: 'flex', flexDirection: 'row', gap: 30, alignItems: 'center', justifyContent: 'center' }}>
                            <Text style={{ marginLeft: 5, fontSize: 13 }}>{option.label}</Text>
                            <Text style={{ fontSize: 13 }}>₹{option.price}</Text>
                        </View>
                    </View>
                ))}

                <TouchableOpacity
                    style={{ borderRadius: 7, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'black' }}
                    onPress={handleConfirm}
                >
                    <Text style={{ color: 'white' }}>Confirm</Text>
                </TouchableOpacity>
            </View>

            
        </View>
    );
};

export default RechargeOptions;

const styles = StyleSheet.create({});
